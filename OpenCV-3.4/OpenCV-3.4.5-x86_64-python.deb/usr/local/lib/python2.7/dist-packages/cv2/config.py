BINARIES_PATHS = [
    os.path.join(os.path.join(LOADER_DIR, '../../../../'), 'lib')
] + BINARIES_PATHS
